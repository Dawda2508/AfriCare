import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import Head from "next/head";
import { verifyPayment } from "../../lib/payments";

export default function PaymentCallback() {
  const router = useRouter();
  const [status, setStatus] = useState("verifying");
  const [booking, setBooking] = useState(null);

  useEffect(() => {
    const { transaction_id, status: flwStatus, tx_ref } = router.query;
    if (!transaction_id) return;

    if (flwStatus === "cancelled") {
      setStatus("cancelled");
      return;
    }

    fetch(`/api/payments/verify?transaction_id=${transaction_id}&tx_ref=${tx_ref}`)
      .then(r => r.json())
      .then(data => {
        if (data.success) {
          setStatus("success");
          setBooking(data.booking);
        } else {
          setStatus("failed");
        }
      })
      .catch(() => setStatus("failed"));
  }, [router.query]);

  const S = {
    wrap: { minHeight: "100vh", background: "#F0F4F8", display: "flex", alignItems: "center", justifyContent: "center", padding: 24 },
    card: { background: "#fff", borderRadius: 16, padding: 40, maxWidth: 480, width: "100%", textAlign: "center", border: "0.5px solid #E2E8F0" },
    icon: { fontSize: 52, marginBottom: 20 },
    title: { fontSize: 22, fontWeight: 700, color: "#0D1B2A", marginBottom: 10 },
    sub: { fontSize: 14, color: "#64748B", lineHeight: 1.7, marginBottom: 24 },
    btn: { background: "#00C896", color: "#0D1B2A", border: "none", padding: "12px 28px", borderRadius: 8, fontSize: 15, fontWeight: 600, cursor: "pointer" },
  };

  return (
    <>
      <Head><title>Payment — AfriCare Health Gambia</title></Head>
      <div style={S.wrap}>
        <div style={S.card}>
          {status === "verifying" && (
            <>
              <div style={S.icon}>⏳</div>
              <div style={S.title}>Verifying payment...</div>
              <div style={S.sub}>Please wait while we confirm your payment.</div>
            </>
          )}
          {status === "success" && (
            <>
              <div style={S.icon}>✅</div>
              <div style={S.title}>Booking confirmed!</div>
              <div style={S.sub}>
                Your consultation has been booked successfully. You will receive a WhatsApp confirmation message shortly.
                {booking?.doctorName && <><br /><strong>Doctor: {booking.doctorName}</strong></>}
              </div>
              <button style={S.btn} onClick={() => router.push("/")}>Back to AfriCare</button>
            </>
          )}
          {status === "failed" && (
            <>
              <div style={S.icon}>❌</div>
              <div style={S.title}>Payment failed</div>
              <div style={S.sub}>Something went wrong with your payment. Please try again or contact support@africare.gm</div>
              <button style={S.btn} onClick={() => router.push("/")}>Try again</button>
            </>
          )}
          {status === "cancelled" && (
            <>
              <div style={S.icon}>↩️</div>
              <div style={S.title}>Payment cancelled</div>
              <div style={S.sub}>Your payment was cancelled. No charges were made.</div>
              <button style={S.btn} onClick={() => router.push("/")}>Back to AfriCare</button>
            </>
          )}
        </div>
      </div>
    </>
  );
}
