// GET /api/doctors
// Query params: ?specialty=&diaspora=true&availableNow=true

import { getDoctors } from "../../../lib/supabase";

export default async function handler(req, res) {
  if (req.method !== "GET") return res.status(405).json({ error: "Method not allowed" });

  const { specialty, diaspora, availableNow } = req.query;

  try {
    const doctors = await getDoctors({
      specialty: specialty || undefined,
      diaspora: diaspora === "true" ? true : diaspora === "false" ? false : undefined,
      availableNow: availableNow === "true",
    });
    return res.status(200).json({ success: true, count: doctors.length, doctors });
  } catch (err) {
    console.error("Doctors fetch error:", err);
    return res.status(500).json({ error: err.message });
  }
}
