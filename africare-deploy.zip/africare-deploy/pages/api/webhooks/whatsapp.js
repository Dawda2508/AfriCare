// POST /api/webhooks/whatsapp
// Receives inbound WhatsApp messages from 360Dialog
// Add this URL in 360Dialog dashboard → Webhooks

import { supabaseAdmin } from "../../../lib/supabase";
import { updateBookingStatus } from "../../../lib/supabase";
import { sendConsultationComplete, sendFreeText } from "../../../lib/whatsapp";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  try {
    const body = req.body;
    const messages = body?.messages || [];

    for (const msg of messages) {
      const from = msg.from;
      const text = (msg.text?.body || "").trim().toUpperCase();

      const admin = supabaseAdmin();

      // ── DOCTOR COMMANDS ──────────────────────────────
      // Doctor replies DONE-AC-XXXX to mark consultation complete
      if (text.startsWith("DONE-AC-")) {
        const bookingRef = text.replace("DONE-", "");
        const { data: booking } = await admin
          .from("bookings")
          .select("*, patients(full_name, phone)")
          .eq("booking_ref", bookingRef)
          .single();

        if (booking) {
          await updateBookingStatus(booking.id, "completed");
          await sendConsultationComplete({
            phone: booking.patients.phone,
            patientName: booking.patients.full_name,
            doctorName: booking.doctors?.full_name || "your doctor",
            bookingRef,
          });
          await sendFreeText({ phone: from, message: `Consultation ${bookingRef} marked as complete. Payout will be processed within 24 hours.` });
        }
        continue;
      }

      // Doctor sets availability: AVAILABLE or UNAVAILABLE
      if (text === "AVAILABLE" || text === "UNAVAILABLE") {
        const { data: doctor } = await admin.from("doctors").select("id").eq("phone", from).single();
        if (doctor) {
          await admin.from("doctors").update({
            is_available_now: text === "AVAILABLE",
            availability_updated_at: new Date().toISOString(),
          }).eq("id", doctor.id);
          await sendFreeText({ phone: from, message: `Your status is now: ${text === "AVAILABLE" ? "Available for instant consultations" : "Unavailable"}` });
        }
        continue;
      }

      // ── PATIENT COMMANDS ─────────────────────────────
      // Patient replies CANCEL to cancel a booking
      if (text === "CANCEL") {
        const { data: booking } = await admin
          .from("bookings")
          .select("id, booking_ref")
          .eq("patient_phone", from)
          .eq("status", "pending")
          .order("created_at", { ascending: false })
          .limit(1)
          .single();

        if (booking) {
          await updateBookingStatus(booking.id, "cancelled");
          await sendFreeText({ phone: from, message: `Your booking ${booking.booking_ref} has been cancelled. Contact us at support@africare.gm for any refund queries.` });
        } else {
          await sendFreeText({ phone: from, message: "No pending booking found to cancel. Reply HELP for assistance." });
        }
        continue;
      }

      // Patient replies HELP
      if (text === "HELP") {
        await sendFreeText({
          phone: from,
          message: "AfriCare Health Support:\n\n• To cancel a booking: Reply CANCEL\n• To book: Visit africare.gm\n• Emergency: Call RVTH +220 422 8223\n• Email: support@africare.gm",
        });
        continue;
      }

      // Rating reply (1-5 after consultation)
      if (["1", "2", "3", "4", "5"].includes(text)) {
        const rating = parseInt(text);
        const { data: booking } = await admin
          .from("bookings")
          .select("id, doctor_id")
          .eq("patient_phone", from)
          .eq("status", "completed")
          .order("updated_at", { ascending: false })
          .limit(1)
          .single();

        if (booking) {
          await admin.from("ratings").insert({ booking_id: booking.id, doctor_id: booking.doctor_id, rating });
          // Recalculate doctor average rating
          const { data: ratings } = await admin.from("ratings").select("rating").eq("doctor_id", booking.doctor_id);
          if (ratings?.length) {
            const avg = ratings.reduce((s, r) => s + r.rating, 0) / ratings.length;
            await admin.from("doctors").update({ rating: Math.round(avg * 10) / 10 }).eq("id", booking.doctor_id);
          }
          await sendFreeText({ phone: from, message: `Thank you for rating your consultation ${rating}/5. Your feedback helps us improve AfriCare Health.` });
        }
        continue;
      }
    }

    return res.status(200).json({ received: true });
  } catch (err) {
    console.error("WhatsApp webhook error:", err);
    return res.status(500).json({ error: err.message });
  }
}
