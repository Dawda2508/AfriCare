// POST /api/webhooks/flutterwave
// Receives payment events from Flutterwave
// Add this URL in Flutterwave dashboard → Settings → Webhooks

import { verifyWebhookSignature, verifyPayment, calculateSplit } from "../../../lib/payments";
import { supabaseAdmin } from "../../../lib/supabase";
import { sendConsultationComplete, sendPayoutNotification } from "../../../lib/whatsapp";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  // Verify the request is genuinely from Flutterwave
  const signature = req.headers["verif-hash"];
  if (!verifyWebhookSignature(signature, req.body)) {
    return res.status(401).json({ error: "Invalid webhook signature" });
  }

  const { event, data } = req.body;

  try {
    if (event === "charge.completed" && data.status === "successful") {
      // 1. Verify payment on Flutterwave (never trust the webhook alone)
      const verified = await verifyPayment(data.id);
      if (verified.status !== "successful") {
        return res.status(200).json({ received: true, action: "ignored — payment not verified" });
      }

      const admin = supabaseAdmin();
      const txRef = verified.tx_ref;
      const amount = verified.amount;

      // 2. Find the booking this payment belongs to
      const { data: payment } = await admin
        .from("payments")
        .select("*, bookings(*, doctors(full_name, phone, id), patients(full_name, phone))")
        .eq("tx_ref", txRef)
        .single();

      if (!payment) {
        return res.status(200).json({ received: true, action: "ignored — payment record not found" });
      }

      // 3. Mark payment as completed
      await admin.from("payments").update({ status: "completed", flw_transaction_id: verified.id, amount }).eq("tx_ref", txRef);

      // 4. Mark booking as paid / active
      await admin.from("bookings").update({ status: "paid" }).eq("id", payment.booking_id);

      // 5. Calculate the 40/60 revenue split
      const { doctorShare, afriCareShare } = calculateSplit(amount);

      // 6. Record the split in the ledger
      await admin.from("revenue_splits").insert({
        booking_id: payment.booking_id,
        total_amount: amount,
        africare_share: afriCareShare,
        doctor_share: doctorShare,
        doctor_id: payment.bookings.doctors.id,
        status: "pending_payout",
      });

      // 7. Notify doctor of pending payout
      const payoutRef = `PAY-${Date.now()}`;
      await sendPayoutNotification({
        phone: payment.bookings.doctors.phone,
        doctorName: payment.bookings.doctors.full_name,
        amount: doctorShare,
        payoutRef,
      });

      return res.status(200).json({ received: true, action: "payment processed", split: { doctorShare, afriCareShare } });
    }

    // Ignore other events
    return res.status(200).json({ received: true, action: "event ignored" });

  } catch (err) {
    console.error("Webhook error:", err);
    return res.status(500).json({ error: err.message });
  }
}
