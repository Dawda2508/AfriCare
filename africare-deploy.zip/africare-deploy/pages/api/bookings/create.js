// POST /api/bookings/create
// Creates a booking, sends WhatsApp confirmations to patient and doctor

import { supabaseAdmin } from "../../../lib/supabase";
import { createBooking, getDoctorById, getPatientByPhone, createPatient } from "../../../lib/supabase";
import { sendBookingConfirmation, sendInstantDoctorRequest } from "../../../lib/whatsapp";
import { generateTxRef } from "../../../lib/payments";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({ error: "Method not allowed" });

  const { patientName, patientPhone, doctorId, bookingType, scheduledAt, notes, plan } = req.body;

  if (!patientName || !patientPhone || !doctorId || !bookingType) {
    return res.status(400).json({ error: "Missing required fields: patientName, patientPhone, doctorId, bookingType" });
  }

  if (!["instant", "instant_urgent", "scheduled"].includes(bookingType)) {
    return res.status(400).json({ error: "bookingType must be: instant, instant_urgent, or scheduled" });
  }

  try {
    // 1. Get or create patient record
    let patient = await getPatientByPhone(patientPhone);
    if (!patient) {
      patient = await createPatient({ fullName: patientName, phone: patientPhone, plan: plan || "basic" });
    }

    // 2. Get doctor details
    const doctor = await getDoctorById(doctorId);
    if (!doctor) return res.status(404).json({ error: "Doctor not found" });
    if (!doctor.is_approved) return res.status(400).json({ error: "Doctor not yet approved" });

    // 3. For instant bookings, check doctor is available
    if ((bookingType === "instant" || bookingType === "instant_urgent") && !doctor.is_available_now) {
      return res.status(409).json({ error: "Doctor is not available right now. Please try another doctor or book a scheduled appointment." });
    }

    // 4. Create booking record
    const bookingRef = generateTxRef("AC");
    const booking = await createBooking({
      patientId: patient.id,
      doctorId: doctor.id,
      type: bookingType,
      scheduledAt: scheduledAt || null,
      notes: notes || null,
    });

    // 5. Send WhatsApp confirmation to patient
    await sendBookingConfirmation({
      phone: patientPhone,
      patientName,
      doctorName: doctor.full_name,
      specialty: doctor.specialty,
      scheduledAt: scheduledAt ? new Date(scheduledAt).toLocaleString("en-GB", { timeZone: "Africa/Banjul" }) : "As soon as possible",
      bookingRef,
    });

    // 6. Notify doctor via WhatsApp
    if (bookingType === "instant" || bookingType === "instant_urgent") {
      await sendInstantDoctorRequest({
        doctorPhone: doctor.phone,
        patientName,
        patientPhone,
        bookingRef,
        isUrgent: bookingType === "instant_urgent",
      });
    }

    return res.status(201).json({
      success: true,
      booking: { id: booking.id, ref: bookingRef, status: "pending", doctorName: doctor.full_name },
      message: `Booking confirmed. You will receive a WhatsApp message on ${patientPhone} shortly.`,
    });

  } catch (err) {
    console.error("Booking error:", err);
    return res.status(500).json({ error: err.message || "Failed to create booking" });
  }
}
