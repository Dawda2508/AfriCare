import { useState, useEffect } from "react";
import Head from "next/head";
import { getDoctors, PLANS } from "../lib/supabase";

const NAV_LINKS = ["Find a doctor", "How it works", "Pricing", "Home services"];

const SERVICES = [
  { icon: "⚡", name: "Instant doctor", desc: "Speak to a doctor right now via WhatsApp. No appointment needed.", fee: "From GMD 375", color: "#FF6B35", bg: "#FFF0EB" },
  { icon: "📅", name: "Scheduled", desc: "Book with your preferred local or diaspora doctor at a chosen time.", fee: "From GMD 375", color: "#00A87A", bg: "#E0FBF4" },
  { icon: "🔬", name: "Home lab collection", desc: "A lab technician visits your home to collect samples.", fee: "+ GMD 150–300", color: "#7B5EA7", bg: "#F0EBF8" },
  { icon: "🩺", name: "Doctor home visit", desc: "A verified local doctor visits you at home (Greater Banjul).", fee: "+ GMD 500–800", color: "#0D1B2A", bg: "#F0F4F8" },
];

const MOCK_DOCTORS = [
  { id: 1, full_name: "Dr. Jainaba Njie", specialty: "General Practitioner", location: "Banjul", is_diaspora: false, is_available_now: true, consultation_fee: 375, rating: 5.0, avatar_initials: "JN", avatar_color: "#1D9E75", is_urgent: false },
  { id: 2, full_name: "Dr. Fatou Darboe", specialty: "Paediatrician", location: "Serrekunda", is_diaspora: false, is_available_now: true, consultation_fee: 500, rating: 4.5, avatar_initials: "FD", avatar_color: "#993C1D", is_urgent: true },
  { id: 3, full_name: "Dr. Bakary Jallow", specialty: "Cardiologist", location: "London, UK", is_diaspora: true, is_available_now: false, consultation_fee: 875, rating: 5.0, avatar_initials: "BJ", avatar_color: "#185FA5", is_urgent: false },
  { id: 4, full_name: "Dr. Mariama Kah", specialty: "OB/GYN Specialist", location: "Westfield Clinic", is_diaspora: false, is_available_now: true, consultation_fee: 625, rating: 5.0, avatar_initials: "MK", avatar_color: "#BA7517", is_urgent: false },
  { id: 5, full_name: "Dr. Alieu Sanneh", specialty: "Internal Medicine", location: "Toronto, Canada", is_diaspora: true, is_available_now: false, consultation_fee: 1000, rating: 5.0, avatar_initials: "AS", avatar_color: "#534AB7", is_urgent: false },
  { id: 6, full_name: "Dr. Lamin Jawara", specialty: "Dermatologist", location: "Berlin, Germany", is_diaspora: true, is_available_now: false, consultation_fee: 812, rating: 4.5, avatar_initials: "LJ", avatar_color: "#0F6E56", is_urgent: false },
];

export default function Home() {
  const [doctors, setDoctors] = useState(MOCK_DOCTORS);
  const [activeTab, setActiveTab] = useState("home");
  const [onlineCount, setOnlineCount] = useState(14);
  const [filterDiaspora, setFilterDiaspora] = useState(null);
  const [filterAvailable, setFilterAvailable] = useState(false);

  useEffect(() => {
    // In production: fetch real doctors from Supabase
    // getDoctors().then(setDoctors).catch(console.error);

    // Simulate live online count fluctuation
    const interval = setInterval(() => {
      setOnlineCount(prev => Math.max(8, Math.min(20, prev + (Math.random() > 0.5 ? 1 : -1))));
    }, 30000);
    return () => clearInterval(interval);
  }, []);

  const filteredDoctors = doctors.filter(d => {
    if (filterDiaspora !== null && d.is_diaspora !== filterDiaspora) return false;
    if (filterAvailable && !d.is_available_now) return false;
    return true;
  });

  return (
    <>
      <Head><title>AfriCare Health Gambia — Telemedicine Platform</title></Head>

      {/* NAV */}
      <nav style={styles.nav}>
        <div style={styles.navLogo}>
          <div style={styles.navLogoIcon}>❤️</div>
          <div>
            <div style={styles.navLogoText}>AfriCare Health</div>
            <div style={styles.navLogoSub}>Gambia&apos;s telemedicine platform</div>
          </div>
        </div>
        <div style={styles.navLinks}>
          {NAV_LINKS.map(l => <a key={l} href="#" style={styles.navLink}>{l}</a>)}
          <button style={styles.navInstant} onClick={() => setActiveTab("instant")}>⚡ Instant doctor</button>
          <button style={styles.navCta}>Get started</button>
        </div>
      </nav>

      {/* LIVE BANNER */}
      <div style={styles.banner}>
        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span style={styles.pulseDot} className="pulse"></span>
          <span style={{ color: "rgba(255,255,255,0.85)", fontSize: 13 }}>
            Live — {onlineCount} doctors available right now · no appointment needed
          </span>
        </div>
        <button style={styles.bannerBtn} onClick={() => setActiveTab("instant")}>
          See doctors now →
        </button>
      </div>

      {/* TABS */}
      <div style={styles.tabs}>
        {["home", "instant", "doctors", "plans", "home-services"].map(tab => (
          <button
            key={tab}
            style={{ ...styles.tab, ...(activeTab === tab ? styles.tabActive : {}) }}
            onClick={() => setActiveTab(tab)}
          >
            {tab === "home-services" ? "Home services" : tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      {/* CONTENT */}
      <main style={styles.main}>

        {/* ── HOME ── */}
        {activeTab === "home" && (
          <div>
            {/* Hero */}
            <div style={styles.hero}>
              <div style={styles.heroLeft}>
                <div style={styles.heroBadge}>🇬🇲 Proudly made for The Gambia</div>
                <h1 style={styles.heroTitle}>
                  Quality healthcare<br />
                  <span style={{ color: "#00C896" }}>instantly available</span><br />
                  across The Gambia
                </h1>
                <p style={styles.heroDesc}>
                  Verified Gambian doctors — local and from the diaspora — via WhatsApp.
                  Connect right now or book ahead, 24/7.
                </p>
                <div style={{ display: "flex", gap: 12 }}>
                  <button style={styles.btnCoral} onClick={() => setActiveTab("instant")}>⚡ See doctors now</button>
                  <button style={styles.btnEmerald} onClick={() => setActiveTab("doctors")}>Book consultation</button>
                </div>
              </div>
              <InstantPanel doctors={doctors.filter(d => d.is_available_now)} />
            </div>

            {/* Stats */}
            <div style={styles.stats}>
              {[
                { num: "127+", label: "Verified doctors", color: "#00C896" },
                { num: onlineCount.toString(), label: "Online right now", color: "#FF6B35" },
                { num: "4,800+", label: "Consultations done", color: "#0D1B2A" },
                { num: "4.9★", label: "Patient rating", color: "#F5A623" },
                { num: "6", label: "Partner labs", color: "#7B5EA7" },
              ].map(s => (
                <div key={s.label} style={styles.statCard}>
                  <div style={{ ...styles.statNum, color: s.color }}>{s.num}</div>
                  <div style={styles.statLabel}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Services */}
            <h2 style={styles.sectionTitle}>Four ways to get care</h2>
            <div style={styles.servicesGrid}>
              {SERVICES.map(s => (
                <div key={s.name} style={{ ...styles.serviceCard, borderColor: s.color + "40", background: s.bg }}>
                  <div style={{ fontSize: 32, marginBottom: 12 }}>{s.icon}</div>
                  <div style={{ fontSize: 15, fontWeight: 600, color: "#0D1B2A", marginBottom: 6 }}>{s.name}</div>
                  <div style={{ fontSize: 13, color: "#64748B", lineHeight: 1.6, marginBottom: 10 }}>{s.desc}</div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: s.color }}>{s.fee}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── INSTANT ── */}
        {activeTab === "instant" && (
          <div>
            <h2 style={{ ...styles.sectionTitle, color: "#FF6B35" }}>⚡ Doctors available right now</h2>
            <div style={styles.instantGrid}>
              <div>
                <div style={styles.urgentLabel}>Critical / urgent slot</div>
                {doctors.filter(d => d.is_urgent).map(d => (
                  <DoctorRow key={d.id} doctor={d} isUrgent />
                ))}
                <div style={{ ...styles.urgentLabel, color: "#00A87A", marginTop: 16 }}>Standard instant</div>
                {doctors.filter(d => d.is_available_now && !d.is_urgent).map(d => (
                  <DoctorRow key={d.id} doctor={d} />
                ))}
                <div style={{ ...styles.urgentLabel, color: "#94A3B8", marginTop: 16 }}>In consultation</div>
                {doctors.filter(d => !d.is_available_now).slice(0, 2).map(d => (
                  <DoctorRow key={d.id} doctor={d} busy />
                ))}
              </div>
              <HowItWorks />
            </div>
          </div>
        )}

        {/* ── DOCTORS ── */}
        {activeTab === "doctors" && (
          <div>
            <h2 style={styles.sectionTitle}>Verified doctors</h2>
            <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
              {[
                { label: "All doctors", value: null, key: "all" },
                { label: "Local only", value: false, key: "local" },
                { label: "Diaspora only", value: true, key: "diaspora" },
              ].map(f => (
                <button
                  key={f.key}
                  onClick={() => setFilterDiaspora(f.value)}
                  style={{ ...styles.filterBtn, ...(filterDiaspora === f.value ? styles.filterBtnActive : {}) }}
                >{f.label}</button>
              ))}
              <button
                onClick={() => setFilterAvailable(!filterAvailable)}
                style={{ ...styles.filterBtn, ...(filterAvailable ? styles.filterBtnActive : {}) }}
              >⚡ Online now only</button>
            </div>
            <div style={styles.doctorsGrid}>
              {filteredDoctors.map(d => <DoctorCard key={d.id} doctor={d} />)}
            </div>
          </div>
        )}

        {/* ── PLANS ── */}
        {activeTab === "plans" && (
          <div>
            <h2 style={styles.sectionTitle}>Choose your care plan</h2>
            <p style={{ color: "#64748B", marginBottom: 28, fontSize: 15 }}>
              All plans include instant doctor access, home lab collection, and doctor home visits. Priced in Gambian Dalasi (GMD).
            </p>
            <div style={styles.plansGrid}>
              {Object.entries(PLANS).map(([key, plan]) => (
                <div key={key} style={{ ...styles.planCard, ...(key === "silver" ? styles.planCardPop : {}) }}>
                  {key === "silver" && <div style={styles.popBadge}>Most popular</div>}
                  <div style={styles.planName}>{plan.name}</div>
                  <div style={styles.planPrice}>GMD {plan.price.toLocaleString()}<span style={styles.planPer}>/mo</span></div>
                  <ul style={styles.planFeatures}>
                    {plan.features.map(f => <li key={f} style={styles.planFeat}>✓ {f}</li>)}
                  </ul>
                  <button style={key === "silver" ? styles.btnEmerald : styles.btnOutline}>
                    Get started
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ── HOME SERVICES ── */}
        {activeTab === "home-services" && (
          <div>
            <h2 style={styles.sectionTitle}>Care that comes to you</h2>
            <p style={{ color: "#64748B", marginBottom: 28, fontSize: 15 }}>
              Home lab collection and doctor visits available across Greater Banjul.
            </p>
            <div style={styles.homeServGrid}>
              {[
                {
                  icon: "🔬", title: "Home lab sample collection", featured: true,
                  sub: "Doctor orders tests — technician visits your home",
                  items: ["Available in Banjul, Serrekunda, Bakau, Fajara", "Partner labs: Westfield MedLab, Kairaba Medical Centre", "Results in 24–48 hours, shared directly with your doctor", "Standard test fees + home collection surcharge"],
                  fee: "Surcharge: GMD 150–300",
                },
                {
                  icon: "🩺", title: "Doctor home visit", featured: false,
                  sub: "Verified local doctor visits you at home",
                  items: ["Greater Banjul metro area initially", "GMC-registered local doctors, opt-in programme", "Ideal for elderly patients, post-surgery, mobility issues", "Book via platform, pay by Afrimoney/QMoney/Wave"],
                  fee: "Surcharge: GMD 500–800",
                },
              ].map(s => (
                <div key={s.title} style={{ ...styles.hsCard, ...(s.featured ? styles.hsCardFeatured : {}) }}>
                  <div style={{ fontSize: 32, marginBottom: 14 }}>{s.icon}</div>
                  <div style={{ fontSize: 17, fontWeight: 600, marginBottom: 4 }}>{s.title}</div>
                  <div style={{ fontSize: 13, color: "#64748B", marginBottom: 14 }}>{s.sub}</div>
                  <ul style={{ paddingLeft: 0 }}>
                    {s.items.map(i => (
                      <li key={i} style={{ listStyle: "none", fontSize: 13, color: "#64748B", padding: "4px 0", display: "flex", gap: 8 }}>
                        <span style={{ color: "#00C896" }}>✓</span>{i}
                      </li>
                    ))}
                  </ul>
                  <div style={styles.feePill}>{s.fee}</div>
                </div>
              ))}
            </div>
          </div>
        )}

      </main>

      {/* FOOTER */}
      <footer style={styles.footer}>
        <div style={styles.footerInner}>
          <div>
            <div style={{ color: "#fff", fontSize: 16, fontWeight: 600 }}>❤️ AfriCare Health Gambia</div>
            <div style={{ color: "rgba(255,255,255,0.45)", fontSize: 12, marginTop: 6, lineHeight: 1.7 }}>
              Gambia&apos;s first telemedicine marketplace.<br />
              Founded by Dawda Touray &amp; Hawah Conteh.
            </div>
          </div>
          <div>
            <div style={styles.footerHead}>Get care</div>
            {["⚡ Instant doctor", "📅 Book consultation", "🔬 Home lab collection", "🩺 Doctor home visit"].map(l => (
              <div key={l} style={styles.footerLink}>{l}</div>
            ))}
          </div>
          <div>
            <div style={styles.footerHead}>For doctors</div>
            {["Join as provider", "Diaspora programme", "Set availability", "Payouts (mobile money)"].map(l => (
              <div key={l} style={styles.footerLink}>{l}</div>
            ))}
          </div>
          <div>
            <div style={styles.footerHead}>Company</div>
            {["About us", "Gambia Medical Council", "Privacy policy", "Contact us"].map(l => (
              <div key={l} style={styles.footerLink}>{l}</div>
            ))}
          </div>
        </div>
        <div style={styles.footerBottom}>
          © 2026 AfriCare Health Gambia · Pay via Afrimoney · QMoney · Wave ·
          <span style={{ color: "#F5A623" }}> Not a substitute for emergency services — RVTH: +220 422 8223</span>
        </div>
      </footer>
    </>
  );
}

// ── SUB-COMPONENTS ──────────────────────────────────────

function InstantPanel({ doctors }) {
  return (
    <div style={{ background: "#1B3A5C", borderRadius: 14, overflow: "hidden", minWidth: 320 }}>
      <div style={{ background: "#FF6B35", padding: "12px 16px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <div style={{ color: "#fff", fontSize: 13, fontWeight: 600 }}>⚡ Instant doctor access</div>
          <div style={{ color: "rgba(255,255,255,0.75)", fontSize: 11 }}>No appointment needed</div>
        </div>
        <div style={{ background: "rgba(255,255,255,0.2)", color: "#fff", padding: "2px 10px", borderRadius: 12, fontSize: 11 }}>Live</div>
      </div>
      <div style={{ padding: 12 }}>
        <div style={{ fontSize: 10, color: "#00C896", fontWeight: 600, marginBottom: 8, textTransform: "uppercase", letterSpacing: 0.5 }}>
          ● Available now
        </div>
        {doctors.map(d => (
          <div key={d.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "8px 10px", borderRadius: 8, marginBottom: 6, background: d.is_urgent ? "rgba(255,107,53,0.15)" : "rgba(255,255,255,0.07)" }}>
            <div style={{ width: 30, height: 30, borderRadius: "50%", background: d.avatar_color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 600, color: "#fff", flexShrink: 0, position: "relative" }}>
              {d.avatar_initials}
              <span style={{ position: "absolute", bottom: 0, right: 0, width: 8, height: 8, borderRadius: "50%", border: "1.5px solid #1B3A5C", background: d.is_urgent ? "#FF6B35" : "#00C896" }}></span>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 11, fontWeight: 600, color: "#fff" }}>{d.full_name}</div>
              <div style={{ fontSize: 10, color: "rgba(255,255,255,0.5)" }}>{d.specialty}</div>
              <div style={{ fontSize: 10, color: d.is_urgent ? "#FF6B35" : "#00C896", fontWeight: 600 }}>
                {d.is_urgent ? `Urgent slot · GMD ${d.consultation_fee}` : `Ready now · GMD ${d.consultation_fee}`}
              </div>
            </div>
            <button style={{ padding: "4px 10px", borderRadius: 5, fontSize: 10, fontWeight: 600, background: d.is_urgent ? "#FF6B35" : "#00C896", color: d.is_urgent ? "#fff" : "#0D1B2A", border: "none" }}>
              {d.is_urgent ? "Urgent" : "Connect"}
            </button>
          </div>
        ))}
        <div style={{ borderTop: "0.5px solid rgba(255,255,255,0.1)", marginTop: 10, paddingTop: 10 }}>
          <div style={{ background: "#FEF5E7", border: "0.5px solid rgba(245,166,35,0.4)", borderRadius: 7, padding: 8, fontSize: 10, color: "#633806", lineHeight: 1.5 }}>
            ⚠️ For life-threatening emergencies call RVTH: <strong>+220 422 8223</strong>
          </div>
        </div>
      </div>
    </div>
  );
}

function DoctorRow({ doctor: d, isUrgent, busy }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "10px 12px", borderRadius: 10, marginBottom: 7, background: busy ? "#F8FAFC" : isUrgent ? "#FFF0EB" : "#fff", border: `0.5px solid ${busy ? "#E2E8F0" : isUrgent ? "rgba(255,107,53,0.3)" : "#E2E8F0"}`, opacity: busy ? 0.5 : 1 }}>
      <div style={{ width: 36, height: 36, borderRadius: "50%", background: d.avatar_color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 600, color: "#fff", flexShrink: 0, position: "relative" }}>
        {d.avatar_initials}
        {!busy && <span style={{ position: "absolute", bottom: 0, right: 0, width: 9, height: 9, borderRadius: "50%", border: "1.5px solid #fff", background: isUrgent ? "#FF6B35" : "#00C896" }}></span>}
      </div>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>{d.full_name}</div>
        <div style={{ fontSize: 11, color: "#64748B" }}>{d.specialty} · {d.location}</div>
        {!busy && <div style={{ fontSize: 11, fontWeight: 600, color: isUrgent ? "#FF6B35" : "#00A87A" }}>
          {isUrgent ? `Urgent slot · GMD ${d.consultation_fee}` : `Ready now · GMD ${d.consultation_fee}`}
        </div>}
        {busy && <div style={{ fontSize: 11, color: "#94A3B8" }}>In consultation</div>}
      </div>
      {!busy && <button style={{ padding: "6px 14px", borderRadius: 6, fontSize: 11, fontWeight: 600, background: isUrgent ? "#FF6B35" : "#00C896", color: isUrgent ? "#fff" : "#0D1B2A", border: "none" }}>
        {isUrgent ? "Urgent →" : "Connect →"}
      </button>}
    </div>
  );
}

function HowItWorks() {
  const steps = [
    { n: 1, title: "See who's online", desc: "Live list of available doctors, updated every 30 seconds." },
    { n: 2, title: "Tap to connect", desc: "Doctor accepts within 60 seconds or auto-routes to next available." },
    { n: 3, title: "Consult via WhatsApp", desc: "Doctor messages you directly — no app download needed." },
    { n: 4, title: "Record saved", desc: "Full consultation notes stored in your AfriCare profile." },
  ];
  return (
    <div style={{ background: "#F0F4F8", borderRadius: 12, padding: 20 }}>
      <div style={{ fontSize: 14, fontWeight: 600, marginBottom: 16 }}>How instant doctor works</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        {steps.map(s => (
          <div key={s.n} style={{ display: "flex", gap: 12, alignItems: "flex-start" }}>
            <div style={{ width: 24, height: 24, borderRadius: "50%", background: "#00C896", color: "#0D1B2A", fontSize: 11, fontWeight: 700, display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>{s.n}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 600 }}>{s.title}</div>
              <div style={{ fontSize: 12, color: "#64748B", marginTop: 2 }}>{s.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function DoctorCard({ doctor: d }) {
  return (
    <div style={{ ...styles.docCard, ...(d.is_available_now && !d.is_urgent ? { borderColor: "rgba(0,200,150,0.4)", background: "#E0FBF4" } : {}), ...(d.is_urgent ? { borderColor: "rgba(255,107,53,0.4)", background: "#FFF0EB" } : {}) }}>
      <div style={{ position: "relative", width: 46, height: 46, marginBottom: 10 }}>
        <div style={{ width: 46, height: 46, borderRadius: "50%", background: d.avatar_color, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 15, fontWeight: 600, color: "#fff" }}>{d.avatar_initials}</div>
        {d.is_available_now && <span style={{ position: "absolute", bottom: 0, right: 0, width: 11, height: 11, borderRadius: "50%", border: "2px solid #fff", background: d.is_urgent ? "#FF6B35" : "#00C896" }}></span>}
      </div>
      <div style={{ fontSize: 14, fontWeight: 600 }}>{d.full_name}</div>
      <div style={{ fontSize: 12, color: "#64748B", margin: "2px 0" }}>{d.specialty}</div>
      <div style={{ fontSize: 12, color: "#64748B" }}>{d.location}</div>
      <div style={{ display: "flex", gap: 5, flexWrap: "wrap", margin: "8px 0" }}>
        <span style={{ ...styles.tag, background: d.is_diaspora ? "#FEF5E7" : "#E0FBF4", color: d.is_diaspora ? "#633806" : "#085041" }}>{d.is_diaspora ? "Diaspora" : "Local"}</span>
        {d.is_available_now && <span style={{ ...styles.tag, background: d.is_urgent ? "#FFF0EB" : "#E0FBF4", color: d.is_urgent ? "#993C1D" : "#085041" }}>{d.is_urgent ? "⚡ Urgent" : "● Online"}</span>}
      </div>
      <div style={{ fontSize: 13, fontWeight: 600, color: "#0D1B2A", marginBottom: 10 }}>GMD {d.consultation_fee.toLocaleString()} / session</div>
      <button style={{ ...styles.docBtn, ...(d.is_available_now ? (d.is_urgent ? { background: "#FF6B35", color: "#fff", border: "none" } : { background: "#00C896", color: "#0D1B2A", border: "none" }) : {}) }}>
        {d.is_available_now ? (d.is_urgent ? "Urgent slot" : "Connect now") : "Book now"}
      </button>
    </div>
  );
}

// ── STYLES ──────────────────────────────────────────────

const styles = {
  nav: { background: "#0D1B2A", padding: "0 32px", display: "flex", alignItems: "center", justifyContent: "space-between", height: 60, position: "sticky", top: 0, zIndex: 100 },
  navLogo: { display: "flex", alignItems: "center", gap: 10 },
  navLogoIcon: { width: 32, height: 32, background: "#00C896", borderRadius: 8, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 },
  navLogoText: { color: "#fff", fontSize: 15, fontWeight: 600 },
  navLogoSub: { color: "rgba(255,255,255,0.4)", fontSize: 10 },
  navLinks: { display: "flex", gap: 20, alignItems: "center" },
  navLink: { color: "rgba(255,255,255,0.65)", fontSize: 13 },
  navInstant: { background: "#FF6B35", color: "#fff", padding: "7px 14px", borderRadius: 7, fontSize: 12, fontWeight: 600 },
  navCta: { background: "#00C896", color: "#0D1B2A", padding: "7px 16px", borderRadius: 7, fontSize: 13, fontWeight: 600 },
  banner: { background: "#1B3A5C", padding: "10px 32px", display: "flex", alignItems: "center", justifyContent: "space-between" },
  pulseDot: { width: 8, height: 8, borderRadius: "50%", background: "#00C896", display: "inline-block" },
  bannerBtn: { background: "#00C896", color: "#0D1B2A", border: "none", padding: "5px 14px", borderRadius: 6, fontSize: 12, fontWeight: 600 },
  tabs: { display: "flex", borderBottom: "0.5px solid #E2E8F0", background: "#fff" },
  tab: { padding: "12px 20px", fontSize: 13, border: "none", background: "transparent", color: "#64748B", borderBottom: "2px solid transparent", cursor: "pointer" },
  tabActive: { color: "#0D1B2A", borderBottom: "2px solid #00C896", fontWeight: 600 },
  main: { maxWidth: 1200, margin: "0 auto", padding: "28px 32px" },
  hero: { background: "#0D1B2A", borderRadius: 16, padding: 28, display: "grid", gridTemplateColumns: "1fr auto", gap: 24, marginBottom: 20 },
  heroLeft: { paddingRight: 16 },
  heroBadge: { display: "inline-block", background: "rgba(0,200,150,0.15)", border: "0.5px solid rgba(0,200,150,0.4)", color: "#00C896", padding: "5px 14px", borderRadius: 20, fontSize: 12, marginBottom: 16 },
  heroTitle: { color: "#fff", fontSize: 32, fontWeight: 700, lineHeight: 1.25, marginBottom: 14 },
  heroDesc: { color: "rgba(255,255,255,0.6)", fontSize: 14, lineHeight: 1.7, marginBottom: 24 },
  btnCoral: { background: "#FF6B35", color: "#fff", padding: "11px 22px", borderRadius: 8, fontSize: 14, fontWeight: 600, border: "none" },
  btnEmerald: { background: "#00C896", color: "#0D1B2A", padding: "11px 22px", borderRadius: 8, fontSize: 14, fontWeight: 600, border: "none" },
  btnOutline: { background: "transparent", color: "#0D1B2A", padding: "11px 22px", borderRadius: 8, fontSize: 14, fontWeight: 600, border: "1.5px solid #0D1B2A", width: "100%" },
  stats: { display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 12, marginBottom: 28 },
  statCard: { background: "#fff", borderRadius: 10, padding: "14px 16px", textAlign: "center", border: "0.5px solid #E2E8F0" },
  statNum: { fontSize: 22, fontWeight: 700 },
  statLabel: { fontSize: 11, color: "#64748B", marginTop: 3 },
  sectionTitle: { fontSize: 22, fontWeight: 700, marginBottom: 20, color: "#0D1B2A" },
  servicesGrid: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 14, marginBottom: 28 },
  serviceCard: { borderRadius: 12, padding: "20px 16px", border: "1.5px solid transparent" },
  instantGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 },
  urgentLabel: { fontSize: 11, fontWeight: 700, color: "#FF6B35", textTransform: "uppercase", letterSpacing: 0.5, marginBottom: 8 },
  doctorsGrid: { display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16 },
  docCard: { background: "#fff", border: "0.5px solid #E2E8F0", borderRadius: 12, padding: 16 },
  tag: { padding: "2px 8px", borderRadius: 8, fontSize: 11, fontWeight: 600 },
  docBtn: { width: "100%", padding: "8px", borderRadius: 7, fontSize: 12, fontWeight: 600, background: "transparent", color: "#0D1B2A", border: "0.5px solid #E2E8F0" },
  filterBtn: { padding: "7px 14px", borderRadius: 7, fontSize: 12, background: "#fff", border: "0.5px solid #E2E8F0", color: "#64748B" },
  filterBtnActive: { background: "#0D1B2A", color: "#fff", border: "0.5px solid #0D1B2A" },
  plansGrid: { display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 16 },
  planCard: { background: "#fff", border: "0.5px solid #E2E8F0", borderRadius: 12, padding: 20, position: "relative" },
  planCardPop: { border: "2px solid #00C896" },
  popBadge: { position: "absolute", top: -12, left: "50%", transform: "translateX(-50%)", background: "#00C896", color: "#0D1B2A", padding: "3px 14px", borderRadius: 10, fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" },
  planName: { fontSize: 14, fontWeight: 600, marginBottom: 6 },
  planPrice: { fontSize: 22, fontWeight: 700, color: "#0D1B2A", margin: "8px 0" },
  planPer: { fontSize: 13, fontWeight: 400, color: "#64748B" },
  planFeatures: { listStyle: "none", margin: "12px 0 16px" },
  planFeat: { fontSize: 12, color: "#64748B", padding: "3px 0" },
  homeServGrid: { display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 },
  hsCard: { background: "#fff", border: "0.5px solid #E2E8F0", borderRadius: 14, padding: 24 },
  hsCardFeatured: { border: "2px solid #00C896" },
  feePill: { display: "inline-block", background: "#E0FBF4", color: "#085041", padding: "6px 14px", borderRadius: 7, fontSize: 12, fontWeight: 600, marginTop: 16 },
  footer: { background: "#0D1B2A", padding: "40px 32px 0" },
  footerInner: { display: "grid", gridTemplateColumns: "2fr 1fr 1fr 1fr", gap: 40, maxWidth: 1200, margin: "0 auto", paddingBottom: 40 },
  footerHead: { color: "#fff", fontSize: 13, fontWeight: 600, marginBottom: 14 },
  footerLink: { color: "rgba(255,255,255,0.45)", fontSize: 12, padding: "4px 0", cursor: "pointer" },
  footerBottom: { borderTop: "0.5px solid rgba(255,255,255,0.1)", padding: "18px 0", textAlign: "center", color: "rgba(255,255,255,0.3)", fontSize: 12, maxWidth: 1200, margin: "0 auto" },
};
