import { Html, Head, Main, NextScript } from "next/document";

export default function Document() {
  return (
    <Html lang="en">
      <Head>
        <meta charSet="utf-8" />
        <meta name="description" content="AfriCare Health Gambia — Gambia's first telemedicine marketplace. Connect with verified local and diaspora Gambian doctors via WhatsApp, 24/7." />
        <meta name="keywords" content="telemedicine Gambia, doctor Gambia, AfriCare, health Gambia, online doctor Gambia" />
        <meta property="og:title" content="AfriCare Health Gambia" />
        <meta property="og:description" content="Speak to a verified Gambian doctor via WhatsApp — instantly or by appointment." />
        <meta property="og:type" content="website" />
        <meta name="theme-color" content="#0D1B2A" />
        <link rel="icon" href="/favicon.ico" />
      </Head>
      <body>
        <Main />
        <NextScript />
      </body>
    </Html>
  );
}
